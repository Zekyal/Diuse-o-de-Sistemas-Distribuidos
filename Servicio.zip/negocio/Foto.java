/*
  Carlos Pineda Guerrero 2017-2020
*/

package negocio;

public class Foto
{
	public int id_foto;
	public byte[] foto;
}
